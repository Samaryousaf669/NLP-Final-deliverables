<nav>
        <ul>
        <li><a href="admin_dashboard.php">Home</a></li>
        <li><a href="add_menu.php">Menu</a></li>
        <li><a href="view_users.php">Users</a></li>
        <li><a href="admin_orders.php">Orders</a></li>
        <li><a href="admin_reservations.php">Reservations</a></li>
        <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>