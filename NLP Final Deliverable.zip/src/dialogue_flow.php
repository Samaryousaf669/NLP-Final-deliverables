<script src="https://www.gstatic.com/dialogflow-console/fast/messenger/bootstrap.js?v=1"></script>
<df-messenger
  intent="WELCOME"
  chat-title="LuxBiteChatbot"
  agent-id="c011bd5a-50f7-4769-b3eb-0d78d7e58f61"
  language-code="en"
></df-messenger>